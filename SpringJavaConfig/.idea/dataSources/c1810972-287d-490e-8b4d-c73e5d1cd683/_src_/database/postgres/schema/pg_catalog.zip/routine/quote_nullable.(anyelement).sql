CREATE FUNCTION quote_nullable (anyelement) RETURNS text
	LANGUAGE sql
AS $$
select pg_catalog.quote_nullable($1::pg_catalog.text)
$$
